(() => {
  if (document.getElementById("creatorpilot-launcher")) return;
  const button = document.createElement("button");
  button.id = "creatorpilot-launcher";
  button.textContent = "✦ CreatorPilot";
  button.title = "Open AI YouTube Growth Assistant";
  button.addEventListener("click", () => window.open("http://localhost:5173", "_blank", "noopener"));
  document.body.appendChild(button);
})();
