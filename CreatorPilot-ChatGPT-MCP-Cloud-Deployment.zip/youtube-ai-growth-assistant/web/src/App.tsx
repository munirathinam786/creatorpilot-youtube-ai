import { useEffect, useState } from "react";
import { Activity, Bot, Check, ChevronRight, CircleHelp, Image, Link2, MessageSquare, Search, ShieldCheck, Sparkles, Youtube, X } from "lucide-react";

const API = import.meta.env.VITE_API_URL || "http://localhost:8787";
async function api(path: string, init: RequestInit = {}) {
  const r = await fetch(API + path, { ...init, credentials: "include", headers: { "Content-Type": "application/json", ...(init.headers || {}) } });
  const data = await r.json().catch(() => ({})); if (!r.ok) throw new Error(data.error || "Request failed"); return data;
}
export default function App() {
  const [connected, setConnected] = useState(false), [channel, setChannel] = useState<any>(null);
  const [videos, setVideos] = useState<any[]>([]), [prompt, setPrompt] = useState("Analyze my recent videos and suggest improvements to titles, descriptions, tags and thumbnail concepts. Prioritize opportunities using the available analytics.");
  const [busy, setBusy] = useState(false), [council, setCouncil] = useState<any[]>([]), [proposals, setProposals] = useState<any[]>([]);
  const [error, setError] = useState(""), [competitorQuery, setCompetitorQuery] = useState(""), [competitors, setCompetitors] = useState<any[]>([]);
  const [tab, setTab] = useState("overview");
  async function refresh() {
    try { const me = await api("/api/me"); setConnected(me.connected); if (me.connected) { const c = await api("/api/channel"); setChannel(c.channel); setVideos(c.videos || []); setProposals(await api("/api/proposals")); } }
    catch (e: any) { setError(e.message); }
  }
  useEffect(() => { refresh(); }, []);
  async function plan() {
    setBusy(true); setError(""); setCouncil([]);
    try { const r = await api("/api/ai/plan", { method: "POST", body: JSON.stringify({ prompt, providers: ["openai", "claude", "gemini"] }) }); setCouncil(r.council); }
    catch (e: any) { setError(e.message); } finally { setBusy(false); }
  }
  async function act(id: string, action: "approve" | "reject") {
    try { await api(`/api/proposals/${id}/${action}`, { method: "POST", body: "{}" }); setProposals(await api("/api/proposals")); }
    catch (e: any) { setError(e.message); }
  }
  async function searchCompetitors() {
    try { setCompetitors(await api(`/api/competitors?q=${encodeURIComponent(competitorQuery)}`)); }
    catch (e: any) { setError(e.message); }
  }
  const stats = channel?.statistics || {};
  return <div className="shell">
    <aside className="sidebar">
      <div className="brand"><div className="brandIcon"><Youtube size={22}/></div><div><b>CreatorPilot</b><small>AI Growth Assistant</small></div></div>
      <div className="navLabel">WORKSPACE</div>
      {["overview","videos","ai studio","approvals","competitors"].map((x) => <button className={`navItem ${tab===x?"active":""}`} onClick={()=>setTab(x)} key={x}>{x==="overview"?<Activity/>:x==="videos"?<Youtube/>:x==="ai studio"?<Sparkles/>:x==="approvals"?<ShieldCheck/>:<Search/>}{x[0].toUpperCase()+x.slice(1)}</button>)}
      <div className="sideBottom"><div className="secure"><ShieldCheck size={16}/> Approval-first mode</div><small>AI suggestions never publish automatically.</small></div>
    </aside>
    <main className="main">
      <header><div><span className="eyebrow">YOUTUBE WORKSPACE</span><h1>{tab==="ai studio"?"AI Studio":tab==="approvals"?"Approval queue":tab==="competitors"?"Competitor research":tab==="videos"?"Your videos":"Channel overview"}</h1></div><div className="headerRight">{connected?<span className="connected"><i/> Channel connected</span>:<button className="primary" onClick={()=>location.href=API+"/api/auth/google/start"}><Link2 size={16}/> Connect YouTube</button>}</div></header>
      {error && <div className="error"><X size={16}/>{error}<button onClick={()=>setError("")}>Dismiss</button></div>}
      {!connected ? <section className="welcome card"><div className="welcomeIcon"><Youtube size={32}/></div><h2>Connect your YouTube channel</h2><p>Connect with Google OAuth to load your channel, videos and analytics. You stay in control: modifications require explicit approval.</p><button className="primary" onClick={()=>location.href=API+"/api/auth/google/start"}>Connect channel <ChevronRight size={17}/></button><p className="muted tiny">Set up Google OAuth credentials in the server environment first.</p></section> :
      <>
      {tab==="overview" && <><section className="statGrid">
        <Stat label="Subscribers" value={Number(stats.subscriberCount||0).toLocaleString()}/><Stat label="Total views" value={Number(stats.viewCount||0).toLocaleString()}/><Stat label="Published videos" value={Number(stats.videoCount||0).toLocaleString()}/><Stat label="Videos analyzed" value={videos.length.toString()}/>
      </section><section className="card"><div className="sectionHead"><div><h2>AI command center</h2><p>Describe the outcome you want in plain language.</p></div><span className="pill"><Sparkles size={13}/> 3-model council</span></div><textarea value={prompt} onChange={e=>setPrompt(e.target.value)} rows={4}/><div className="promptFoot"><span className="muted tiny">ChatGPT · Claude · Gemini</span><button className="primary" disabled={busy||!prompt.trim()} onClick={plan}>{busy?"Analyzing…":<><Sparkles size={16}/> Analyze channel</>}</button></div></section>
      <section className="card"><div className="sectionHead"><div><h2>Recent videos</h2><p>Latest uploads available through YouTube Data API.</p></div><button className="textBtn" onClick={()=>setTab("videos")}>View all <ChevronRight size={15}/></button></div><VideoList videos={videos.slice(0,5)}/></section></>}
      {tab==="videos" && <section className="card"><div className="sectionHead"><div><h2>Channel videos</h2><p>Recent uploads and their public performance counters.</p></div></div><VideoList videos={videos}/></section>}
      {tab==="ai studio" && <section className="card"><div className="sectionHead"><div><h2>Ask your AI council</h2><p>One prompt, three independent perspectives.</p></div></div><textarea rows={5} value={prompt} onChange={e=>setPrompt(e.target.value)}/><div className="promptFoot"><span className="muted tiny">Provider keys are stored on the backend.</span><button className="primary" disabled={busy||!prompt.trim()} onClick={plan}>{busy?"Working…":"Run AI analysis"}</button></div>{council.map((x:any)=><div className="aiResult" key={x.provider}><b>{x.provider?.toUpperCase()}</b><pre>{x.answer||x.error}</pre></div>)}</section>}
      {tab==="approvals" && <section className="card"><div className="sectionHead"><div><h2>Approval queue</h2><p>Review proposed changes before they are applied.</p></div></div>{proposals.length?proposals.map((p:any)=><div className="proposal" key={p.id}><div><span className={`status ${p.status}`}>{p.status}</span><b>{p.action.type}</b><p>{p.rationale}</p><pre>{JSON.stringify(p.action,null,2)}</pre>{p.result&&<small>{p.result}</small>}</div>{p.status==="pending"&&<div className="actions"><button className="approve" onClick={()=>act(p.id,"approve")}><Check size={15}/> Approve & apply</button><button className="reject" onClick={()=>act(p.id,"reject")}>Reject</button></div>}</div>):<p className="muted">No proposals yet. Use AI Studio to generate a plan, then add individual actions for approval.</p>}</section>}
      {tab==="competitors" && <section className="card"><div className="sectionHead"><div><h2>Competitor discovery</h2><p>Search public YouTube videos by topic, channel or keyword.</p></div></div><div className="searchRow"><input value={competitorQuery} onChange={e=>setCompetitorQuery(e.target.value)} placeholder="e.g. beginner photography tips"/><button className="primary" onClick={searchCompetitors}><Search size={16}/> Search</button></div>{competitors.map((c:any)=><div className="competitor" key={c.id?.videoId}><img src={c.snippet?.thumbnails?.default?.url}/><div><b>{c.snippet?.title}</b><small>{c.snippet?.channelTitle}</small></div></div>)}</section>}
      {council.length>0 && tab==="overview" && <section className="card"><div className="sectionHead"><div><h2>AI council results</h2><p>Review the three perspectives below.</p></div></div>{council.map((x:any)=><div className="aiResult" key={x.provider}><b>{x.provider?.toUpperCase()}</b><pre>{x.answer||x.error}</pre></div>)}</section>}
      </>}
      <footer><span>CreatorPilot · YouTube AI Growth Assistant</span><span><CircleHelp size={14}/> API usage and quota limits apply</span></footer>
    </main>
  </div>;
}
function Stat({label,value}:any){return <div className="stat card"><span>{label}</span><b>{value}</b><small>From connected channel</small></div>}
function VideoList({videos}:any){return <div className="videoList">{videos.map((v:any)=><div className="videoRow" key={v.id}><img src={v.snippet?.thumbnails?.medium?.url||v.snippet?.thumbnails?.default?.url}/><div className="videoInfo"><b>{v.snippet?.title}</b><small>{new Date(v.snippet?.publishedAt).toLocaleDateString()} · {v.snippet?.channelTitle}</small></div><div className="videoStats"><b>{Number(v.statistics?.viewCount||0).toLocaleString()}</b><small>views</small></div></div>)}</div>}
