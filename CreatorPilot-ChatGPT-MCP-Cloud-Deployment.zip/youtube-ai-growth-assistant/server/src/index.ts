import "dotenv/config";
import express from "express";
import cors from "cors";
import helmet from "helmet";
import session from "express-session";
import multer from "multer";
import path from "node:path";
import fs from "node:fs";
import { randomBytes } from "node:crypto";
import { authUrl, oauthClient, channelSnapshot, analyticsReport, executeYoutubeAction, searchCompetitors, listComments } from "./youtube.js";
import { runAiCouncil } from "./ai.js";
import { addProposal, listProposals, updateProposal } from "./store.js";
import { handleMcp, mcpAuth, persistOwnerTokens } from "./mcp.js";

declare module "express-session" { interface SessionData { googleTokens?: any; oauthState?: string } }
const app = express();
const uploadDir = path.resolve("uploads"); fs.mkdirSync(uploadDir, { recursive: true });
const upload = multer({ dest: uploadDir, limits: { fileSize: 8 * 1024 * 1024 } });
app.use(helmet({ crossOriginResourcePolicy: { policy: "cross-origin" } }));
app.use(cors({ origin: process.env.WEB_ORIGIN || "http://localhost:5173", credentials: true }));
app.use(express.json({ limit: "2mb" }));
app.use(session({
  secret: process.env.SESSION_SECRET || "development-only-change-me",
  resave: false, saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: "lax", secure: process.env.NODE_ENV === "production", maxAge: 8 * 60 * 60 * 1000 }
}));
const requireAuth = (req: any, res: any, next: any) => req.session.googleTokens ? next() : res.status(401).json({ error: "Connect your YouTube channel first." });

app.get("/api/health", (_req, res) => res.json({ ok: true, service: "CreatorPilot", mcp: "/mcp" }));
app.all("/mcp", mcpAuth, async (req, res) => { try { await handleMcp(req, res); } catch (e: any) { if (!res.headersSent) res.status(500).json({ error: e.message }); } });
app.get("/connect-youtube", (_req, res) => res.redirect("/api/auth/google/start"));
app.get("/api/auth/google/start", (req: any, res) => {
  if (!process.env.GOOGLE_CLIENT_ID || !process.env.GOOGLE_CLIENT_SECRET) return res.status(500).json({ error: "Google OAuth credentials are not configured." });
  const state = randomBytes(24).toString("hex"); req.session.oauthState = state; res.redirect(authUrl(state));
});
app.get("/api/auth/google/callback", async (req: any, res) => {
  try {
    if (!req.query.code || req.query.state !== req.session.oauthState) return res.status(400).send("OAuth state validation failed.");
    const { tokens } = await oauthClient().getToken(String(req.query.code));
    req.session.googleTokens = tokens; persistOwnerTokens(tokens); req.session.oauthState = undefined;
    res.redirect((process.env.WEB_ORIGIN || "http://localhost:5173") + "?connected=1");
  } catch (e: any) { res.status(500).send(`Google connection failed: ${e.message}`); }
});
app.post("/api/auth/disconnect", (req: any, res) => { req.session.googleTokens = undefined; res.json({ ok: true }); });
app.get("/api/me", (req: any, res) => res.json({ connected: !!req.session.googleTokens }));
app.get("/api/channel", requireAuth, async (req: any, res) => { try { res.json(await channelSnapshot(req.session.googleTokens)); } catch (e: any) { res.status(500).json({ error: e.message }); } });
app.get("/api/analytics", requireAuth, async (req: any, res) => {
  try {
    const end = String(req.query.end || new Date().toISOString().slice(0, 10));
    const start = String(req.query.start || new Date(Date.now() - 28 * 86400000).toISOString().slice(0, 10));
    res.json(await analyticsReport(req.session.googleTokens, start, end));
  } catch (e: any) { res.status(500).json({ error: e.message }); }
});
app.get("/api/comments/:videoId", requireAuth, async (req: any, res) => { try { res.json(await listComments(req.session.googleTokens, req.params.videoId)); } catch (e: any) { res.status(500).json({ error: e.message }); } });
app.get("/api/competitors", requireAuth, async (req: any, res) => {
  try { const q = String(req.query.q || "").slice(0, 150); if (!q) return res.status(400).json({ error: "Provide a search query." }); res.json(await searchCompetitors(req.session.googleTokens, q)); }
  catch (e: any) { res.status(500).json({ error: e.message }); }
});
app.post("/api/ai/plan", requireAuth, async (req: any, res) => {
  try {
    const { prompt, providers = ["openai", "claude", "gemini"] } = req.body || {};
    if (!prompt || typeof prompt !== "string") return res.status(400).json({ error: "A prompt is required." });
    const safeProviders = providers.filter((p: string) => ["openai", "claude", "gemini"].includes(p));
    const context = await channelSnapshot(req.session.googleTokens);
    const council = await runAiCouncil(prompt.slice(0, 6000), context, safeProviders);
    res.json({ council, note: "AI output is advisory. Review and explicitly create/approve proposals before any channel changes." });
  } catch (e: any) { res.status(500).json({ error: e.message }); }
});
app.post("/api/proposals", requireAuth, (req: any, res) => {
  const { action, rationale } = req.body || {};
  const allowed = ["updateVideo", "setThumbnail", "replyComment"];
  if (!action || !allowed.includes(action.type) || !rationale) return res.status(400).json({ error: "Invalid proposal." });
  if (action.type === "updateVideo" && !action.videoId) return res.status(400).json({ error: "videoId is required." });
  if (action.type === "replyComment" && (!action.parentId || !action.text)) return res.status(400).json({ error: "parentId and text are required." });
  res.json(addProposal({ action, rationale }));
});
app.get("/api/proposals", requireAuth, (_req, res) => res.json(listProposals()));
app.post("/api/proposals/:id/reject", requireAuth, (req, res) => {
  const p = updateProposal(req.params.id, { status: "rejected" }); if (!p) return res.status(404).json({ error: "Proposal not found." }); res.json(p);
});
app.post("/api/proposals/:id/approve", requireAuth, async (req: any, res) => {
  const proposal = listProposals().find(p => p.id === req.params.id);
  if (!proposal || proposal.status !== "pending") return res.status(404).json({ error: "Pending proposal not found." });
  try {
    const result = await executeYoutubeAction(req.session.googleTokens, proposal.action);
    const updated = updateProposal(proposal.id, { status: "approved", result }); res.json(updated);
  } catch (e: any) {
    const updated = updateProposal(proposal.id, { status: "failed", result: e.message }); res.status(500).json(updated);
  }
});
app.post("/api/thumbnails/upload", requireAuth, upload.single("image"), (req: any, res) => {
  if (!req.file) return res.status(400).json({ error: "Image file required." });
  res.json({ imagePath: path.resolve(req.file.path), filename: req.file.originalname, note: "Create a setThumbnail proposal using this imagePath." });
});
app.post("/api/thumbnails/generate", requireAuth, async (req: any, res) => {
  try {
    const key = process.env.OPENAI_API_KEY; if (!key) return res.status(501).json({ error: "Set OPENAI_API_KEY to enable thumbnail generation." });
    const { prompt } = req.body || {}; if (!prompt) return res.status(400).json({ error: "prompt required" });
    const r = await fetch("https://api.openai.com/v1/images/generations", {
      method: "POST", headers: { Authorization: `Bearer ${key}`, "Content-Type": "application/json" },
      body: JSON.stringify({ model: process.env.OPENAI_IMAGE_MODEL || "gpt-image-1", prompt: `Create a polished, original YouTube thumbnail, 16:9 composition, bold focal subject, legible visual hierarchy, no fake logos or misleading claims. ${String(prompt).slice(0, 1500)}`, size: "1536x1024" })
    });
    const j: any = await r.json(); if (!r.ok) throw new Error(j.error?.message || "Image generation failed");
    const b64 = j.data?.[0]?.b64_json; if (!b64) throw new Error("Image provider returned no image data.");
    const file = path.join(uploadDir, `${Date.now()}-thumbnail.png`); fs.writeFileSync(file, Buffer.from(b64, "base64"));
    res.json({ imagePath: path.resolve(file), previewUrl: `/uploads/${path.basename(file)}` });
  } catch (e: any) { res.status(500).json({ error: e.message }); }
});
app.use("/uploads", express.static(uploadDir));
const port = Number(process.env.PORT || 8787);
app.listen(port, () => console.log(`YouTube AI Growth API listening on http://localhost:${port}`));
