import { google } from "googleapis";
import fs from "node:fs";

export function oauthClient() {
  return new google.auth.OAuth2(
    process.env.GOOGLE_CLIENT_ID, process.env.GOOGLE_CLIENT_SECRET,
    process.env.GOOGLE_REDIRECT_URI
  );
}
export function authUrl(state: string) {
  return oauthClient().generateAuthUrl({
    access_type: "offline", prompt: "consent", state,
    scope: [
      "openid", "email", "profile",
      "https://www.googleapis.com/auth/youtube.readonly",
      "https://www.googleapis.com/auth/youtube",
      "https://www.googleapis.com/auth/yt-analytics.readonly",
      "https://www.googleapis.com/auth/youtube.force-ssl"
    ]
  });
}
export async function getYoutube(tokens: any) {
  const auth = oauthClient(); auth.setCredentials(tokens);
  return { youtube: google.youtube({ version: "v3", auth }), analytics: google.youtubeAnalytics({ version: "v2", auth }) };
}
export async function channelSnapshot(tokens: any) {
  const { youtube } = await getYoutube(tokens);
  const channel = await youtube.channels.list({ part: ["snippet", "statistics", "contentDetails"], mine: true });
  const uploads = channel.data.items?.[0]?.contentDetails?.relatedPlaylists?.uploads;
  let videos: any[] = [];
  if (uploads) {
    const playlist = await youtube.playlistItems.list({ part: ["snippet", "contentDetails"], playlistId: uploads, maxResults: 25 });
    const ids = (playlist.data.items || []).map(x => x.contentDetails?.videoId).filter(Boolean) as string[];
    if (ids.length) {
      const details = await youtube.videos.list({ part: ["snippet", "statistics", "contentDetails"], id: ids });
      videos = details.data.items || [];
    }
  }
  return { channel: channel.data.items?.[0] || null, videos };
}
export async function analyticsReport(tokens: any, startDate: string, endDate: string) {
  const { analytics } = await getYoutube(tokens);
  const r = await analytics.reports.query({
    ids: "channel==MINE", startDate, endDate,
    metrics: "views,estimatedMinutesWatched,averageViewDuration,averageViewPercentage,subscribersGained",
    dimensions: "day", sort: "day"
  });
  return r.data;
}
export async function executeYoutubeAction(tokens: any, action: any) {
  const { youtube } = await getYoutube(tokens);
  if (action.type === "updateVideo") {
    const current = await youtube.videos.list({ part: ["snippet"], id: [action.videoId] });
    const snippet = current.data.items?.[0]?.snippet;
    if (!snippet) throw new Error("Video not found or inaccessible");
    const updated = {
      ...snippet,
      ...(action.title ? { title: action.title } : {}),
      ...(action.description ? { description: action.description } : {}),
      ...(action.tags ? { tags: action.tags } : {}),
      ...(action.categoryId ? { categoryId: action.categoryId } : {})
    };
    const r = await youtube.videos.update({ part: ["snippet"], requestBody: { id: action.videoId, snippet: updated } });
    return `Updated video ${r.data.id}`;
  }
  if (action.type === "setThumbnail") {
    if (!fs.existsSync(action.imagePath)) throw new Error("Thumbnail file not found");
    const r = await youtube.thumbnails.set({ videoId: action.videoId, media: { mimeType: "image/png", body: fs.createReadStream(action.imagePath) } });
    return `Thumbnail uploaded for ${action.videoId}`;
  }
  if (action.type === "replyComment") {
    const r = await youtube.comments.insert({ part: ["snippet"], requestBody: { snippet: { parentId: action.parentId, textOriginal: action.text } } });
    return `Reply posted: ${r.data.id}`;
  }
  throw new Error("Unsupported action");
}
export async function searchCompetitors(tokens: any, query: string) {
  const { youtube } = await getYoutube(tokens);
  const r = await youtube.search.list({ part: ["snippet"], q: query, type: ["video"], maxResults: 12, order: "viewCount" });
  return r.data.items || [];
}
export async function listComments(tokens: any, videoId: string) {
  const { youtube } = await getYoutube(tokens);
  const r = await youtube.commentThreads.list({ part: ["snippet"], videoId, maxResults: 50, order: "time", textFormat: "plainText" });
  return r.data.items || [];
}
