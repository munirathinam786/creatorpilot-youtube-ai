import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { StreamableHTTPServerTransport } from "@modelcontextprotocol/sdk/server/streamableHttp.js";
import { z } from "zod";
import type { Request, Response, NextFunction } from "express";
import { channelSnapshot, analyticsReport, executeYoutubeAction, searchCompetitors, listComments } from "./youtube.js";
import { runAiCouncil } from "./ai.js";
import { addProposal, listProposals, updateProposal } from "./store.js";
import fs from "node:fs";
import path from "node:path";

const tokenFile = path.resolve(process.env.DATA_DIR || "./data", "owner-google-tokens.json");

export function persistOwnerTokens(tokens: any) {
  fs.mkdirSync(path.dirname(tokenFile), { recursive: true });
  fs.writeFileSync(tokenFile, JSON.stringify(tokens), { mode: 0o600 });
}
function ownerTokens() {
  if (!fs.existsSync(tokenFile)) throw new Error("YouTube is not connected. Open the CreatorPilot setup URL and connect your Google account first.");
  return JSON.parse(fs.readFileSync(tokenFile, "utf8"));
}
export function mcpAuth(req: Request, res: Response, next: NextFunction) {
  const expected = process.env.MCP_ACCESS_TOKEN;
  if (!expected) return res.status(503).json({ error: "MCP_ACCESS_TOKEN is not configured." });
  const supplied = (req.headers.authorization || "").replace(/^Bearer\s+/i, "");
  if (!supplied || supplied.length !== expected.length ||
      !Buffer.from(supplied).equals(Buffer.from(expected))) {
    return res.status(401).json({ error: "Unauthorized MCP request." });
  }
  next();
}
function textResult(value: unknown) {
  return { content: [{ type: "text" as const, text: JSON.stringify(value, null, 2) }] };
}
function createServer() {
  const server = new McpServer({ name: "CreatorPilot YouTube Growth Assistant", version: "1.0.0" });

  server.registerTool("channel_overview", {
    title: "Get YouTube channel overview",
    description: "Read the connected channel profile, subscriber count, total views, video count and latest uploads. Read-only.",
    inputSchema: {}
  }, async () => textResult(await channelSnapshot(ownerTokens())));

  server.registerTool("channel_analytics", {
    title: "Get YouTube analytics",
    description: "Read daily channel views, watch time, average view duration, average view percentage and subscribers gained for a date range. Read-only.",
    inputSchema: { startDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/), endDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/) }
  }, async ({ startDate, endDate }) => textResult(await analyticsReport(ownerTokens(), startDate, endDate)));

  server.registerTool("analyze_channel", {
    title: "Ask the AI growth council",
    description: "Send a channel snapshot and a growth task to configured ChatGPT, Claude and Gemini APIs. Returns advice only; does not change YouTube.",
    inputSchema: { prompt: z.string().min(3).max(5000), providers: z.array(z.enum(["openai", "claude", "gemini"])).optional() }
  }, async ({ prompt, providers }) => {
    const context = await channelSnapshot(ownerTokens());
    return textResult(await runAiCouncil(prompt, context, providers || ["openai", "claude", "gemini"]));
  });

  server.registerTool("create_video_update_proposal", {
    title: "Propose video metadata changes",
    description: "Create a pending approval proposal to update a video's title, description, tags or category. This does not modify YouTube until approve_proposal is explicitly called.",
    inputSchema: {
      videoId: z.string().min(5),
      title: z.string().max(100).optional(),
      description: z.string().max(5000).optional(),
      tags: z.array(z.string().max(100)).max(30).optional(),
      categoryId: z.string().optional(),
      rationale: z.string().min(3).max(1000)
    }
  }, async ({ videoId, title, description, tags, categoryId, rationale }) => {
    const proposal = addProposal({ action: { type: "updateVideo", videoId, title, description, tags, categoryId }, rationale });
    return textResult({ message: "Proposal created. No YouTube changes have been made.", proposal });
  });

  server.registerTool("list_approval_proposals", {
    title: "List pending YouTube changes",
    description: "Show pending, approved, rejected and failed CreatorPilot proposals. Read-only.",
    inputSchema: {}
  }, async () => textResult(listProposals()));

  server.registerTool("approve_proposal", {
    title: "Approve and apply a YouTube change",
    description: "WRITE ACTION. Applies exactly one previously created pending proposal to the connected YouTube channel. Only call when the user has explicitly asked to approve that specific proposal. Never infer approval from a general optimization request.",
    inputSchema: { proposalId: z.string().uuid() },
    annotations: { readOnlyHint: false, destructiveHint: false, openWorldHint: false }
  }, async ({ proposalId }) => {
    const proposal = listProposals().find(p => p.id === proposalId);
    if (!proposal || proposal.status !== "pending") throw new Error("Pending proposal not found.");
    const result = await executeYoutubeAction(ownerTokens(), proposal.action);
    return textResult(updateProposal(proposalId, { status: "approved", result }));
  });

  server.registerTool("reject_proposal", {
    title: "Reject a YouTube change proposal",
    description: "Reject a pending proposal without changing YouTube.",
    inputSchema: { proposalId: z.string().uuid() }
  }, async ({ proposalId }) => {
    const p = updateProposal(proposalId, { status: "rejected" });
    if (!p) throw new Error("Proposal not found.");
    return textResult(p);
  });

  server.registerTool("search_public_youtube_videos", {
    title: "Research public YouTube competitors",
    description: "Search public YouTube videos by keyword and return public search metadata. Does not expose private competitor analytics.",
    inputSchema: { query: z.string().min(2).max(150) }
  }, async ({ query }) => textResult(await searchCompetitors(ownerTokens(), query)));

  server.registerTool("read_video_comments", {
    title: "Read video comments",
    description: "Read recent comment threads for a video. Read-only.",
    inputSchema: { videoId: z.string().min(5) }
  }, async ({ videoId }) => textResult(await listComments(ownerTokens(), videoId)));

  server.registerTool("propose_comment_reply", {
    title: "Propose a comment reply",
    description: "Create a pending proposal for a reply to a YouTube comment. Does not post until separately approved.",
    inputSchema: { parentId: z.string().min(3), text: z.string().min(1).max(10000), rationale: z.string().min(3).max(1000) }
  }, async ({ parentId, text, rationale }) => textResult(addProposal({ action: { type: "replyComment", parentId, text }, rationale })));

  return server;
}

export async function handleMcp(req: Request, res: Response) {
  const server = createServer();
  const transport = new StreamableHTTPServerTransport({ sessionIdGenerator: undefined });
  res.on("close", () => { void transport.close(); void server.close(); });
  await server.connect(transport);
  await transport.handleRequest(req, res, req.body);
}
