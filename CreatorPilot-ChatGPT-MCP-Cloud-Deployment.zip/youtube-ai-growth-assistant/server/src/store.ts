import fs from "node:fs";
import path from "node:path";
import { randomUUID } from "node:crypto";

export type ProposalAction =
  | { type: "updateVideo"; videoId: string; title?: string; description?: string; tags?: string[]; categoryId?: string }
  | { type: "setThumbnail"; videoId: string; imagePath: string }
  | { type: "replyComment"; parentId: string; text: string };

export type Proposal = {
  id: string; status: "pending" | "approved" | "rejected" | "failed";
  action: ProposalAction; rationale: string; createdAt: string; result?: string;
};

const dir = path.resolve(process.env.DATA_DIR || "./data");
const file = path.join(dir, "proposals.json");
function read(): Proposal[] {
  try { fs.mkdirSync(dir, { recursive: true }); return JSON.parse(fs.readFileSync(file, "utf8")); }
  catch { return []; }
}
function write(items: Proposal[]) {
  fs.mkdirSync(dir, { recursive: true });
  fs.writeFileSync(file, JSON.stringify(items, null, 2));
}
export const listProposals = () => read();
export function addProposal(input: Omit<Proposal, "id" | "createdAt" | "status">) {
  const items = read();
  const p: Proposal = { ...input, id: randomUUID(), createdAt: new Date().toISOString(), status: "pending" };
  items.unshift(p); write(items); return p;
}
export function updateProposal(id: string, patch: Partial<Proposal>) {
  const items = read(); const i = items.findIndex(p => p.id === id);
  if (i < 0) return null;
  items[i] = { ...items[i], ...patch }; write(items); return items[i];
}
