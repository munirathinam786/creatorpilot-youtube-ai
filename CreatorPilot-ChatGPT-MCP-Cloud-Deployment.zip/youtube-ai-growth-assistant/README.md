# CreatorPilot — YouTube AI Growth Assistant

A starter full-stack project with:
- A React web dashboard
- A Manifest V3 Chrome extension that launches the dashboard alongside YouTube Studio
- A Node/Express backend
- Google OAuth + YouTube Data API + YouTube Analytics API
- AI council integrations for OpenAI, Anthropic Claude and Google Gemini
- Approval queue for video metadata updates, thumbnail uploads and comment replies

> This is a functional starter implementation, not a production-audited SaaS. You must configure your own Google Cloud project and AI provider API keys. API quotas, Google verification, channel permissions and provider billing apply.

## Architecture

```text
Chrome extension ─┐
                  ├── React dashboard ── Express API ── Google OAuth / YouTube APIs
Web dashboard ────┘                         ├────────── OpenAI
                                            ├────────── Anthropic
                                            └────────── Gemini
```

## Requirements

- Node.js 20+
- Google Cloud project with YouTube Data API v3 and YouTube Analytics API enabled
- OAuth 2.0 Web application credentials
- API keys for the AI providers you want to use

## Setup

1. Copy `.env.example` to `server/.env` and fill in the values. The backend loads dotenv from its current working directory, so place the file at `server/.env`.
2. In Google Cloud Console, create an OAuth client ID of type **Web application**.
3. Add `http://localhost:8787/api/auth/google/callback` as an authorized redirect URI.
4. Configure the OAuth consent screen and add your Google account as a test user while the app is in testing.
5. Enable **YouTube Data API v3** and **YouTube Analytics API**.
6. From the project root run:

```bash
npm install
npm run dev
```

7. Open `http://localhost:5173`, then click **Connect YouTube**.
8. Load the Chrome extension:
   - Open `chrome://extensions`
   - Enable Developer mode
   - Choose **Load unpacked**
   - Select this project's `extension/` folder
   - Open `https://studio.youtube.com`; the CreatorPilot launcher appears at the bottom-right.

The dashboard is served at port 5173 and API at port 8787.

## AI provider setup

Set any combination of:
- `OPENAI_API_KEY`
- `ANTHROPIC_API_KEY`
- `GEMINI_API_KEY`

Keys stay on the server. Never put provider keys in the extension or browser bundle. The AI council currently returns independent analyses; it does not pretend to have access to private model accounts or chat histories.

## Approval workflow

- `/api/ai/plan` asks the configured models for recommendations.
- `/api/proposals` stores a structured pending action.
- `/api/proposals/:id/approve` executes the supported action against the connected channel.
- `/api/proposals/:id/reject` rejects it.

Supported action shapes:

```json
{
  "action": {
    "type": "updateVideo",
    "videoId": "YOUTUBE_VIDEO_ID",
    "title": "Proposed title",
    "description": "Proposed description",
    "tags": ["topic", "keyword"]
  },
  "rationale": "Why this change is recommended"
}
```

```json
{
  "action": {
    "type": "replyComment",
    "parentId": "YOUTUBE_COMMENT_ID",
    "text": "A thoughtful reply"
  },
  "rationale": "Relevant viewer question"
}
```

```json
{
  "action": {
    "type": "setThumbnail",
    "videoId": "YOUTUBE_VIDEO_ID",
    "imagePath": "/absolute/server/path/to/thumbnail.png"
  },
  "rationale": "Improved visual hierarchy"
}
```

The UI currently displays AI results and existing proposals. To submit proposals, call the API endpoint or extend the UI with a structured proposal editor. Do not parse free-form model output and execute it automatically.

## Current scope and limitations

- **SEO/titles/descriptions/tags:** AI recommendations; metadata can be updated through an approved `updateVideo` proposal.
- **Thumbnails:** generate an image with the OpenAI Images API or upload your own, then approve a `setThumbnail` proposal. YouTube thumbnail limits and accepted formats apply.
- **Analytics:** channel summary and a daily channel analytics report endpoint are included. More dimensions and reports can be added.
- **Shorts:** Shorts can be identified and analyzed as videos, but automated video editing, clipping, captions and upload scheduling are not included yet.
- **Comments:** comment threads can be read; approved replies can be posted. Bulk moderation and deletion are intentionally not automated.
- **Competitors:** uses public YouTube search results; private competitor analytics are not available.
- **Extension:** adds a launcher and opens the dashboard. It does not scrape or modify Studio's private DOM.
- **AI council:** calls each provider independently. Provider errors are shown per model. Add a synthesis step if you want a fourth coordinator pass.
- **Persistence:** proposal records are stored in a local JSON file; OAuth tokens are held in the Express session. Use a persistent database and encrypted token storage for deployment.

## Production hardening checklist

Before deploying for real channel use:
- Replace the default session store with Redis or a database-backed session store.
- Encrypt OAuth refresh tokens at rest; implement token refresh and revocation handling.
- Add CSRF protection, rate limiting, audit logs, role-based access and secure cookie settings.
- Restrict CORS to trusted origins; use HTTPS.
- Validate every proposal against the live video/comment owner and current state before execution.
- Add a proposal editor and before/after diff UI.
- Add rollback snapshots for metadata, and never promise that thumbnail rollback or deleted content can always be restored.
- Request only scopes necessary for the selected features; complete Google's OAuth verification requirements before public release.
- Add unit, integration and end-to-end tests.


## ChatGPT remote MCP deployment (single-owner personal setup)

This project now exposes a remote Streamable HTTP MCP endpoint at `/mcp`. The MCP tools include:
- `channel_overview`
- `channel_analytics`
- `analyze_channel`
- `create_video_update_proposal`
- `list_approval_proposals`
- `approve_proposal`
- `reject_proposal`
- `search_public_youtube_videos`
- `read_video_comments`
- `propose_comment_reply`

### Important deployment model

The included MCP bridge is a **single-owner personal deployment**: one Google/YouTube account is connected by the owner, and ChatGPT authenticates to the MCP endpoint with a private bearer token. Do not share this endpoint or token with other people. A multi-user SaaS needs per-user OAuth authorization, encrypted token storage, tenant isolation, and stronger audit controls.

The Google OAuth callback persists the connected owner's token set under `DATA_DIR/owner-google-tokens.json`. Use a persistent encrypted disk or replace this with a managed secrets/database solution before production. The example Render disk is persistent but does not encrypt the token file at application level.

### Deploy to Render

1. Push this project to a private GitHub repository.
2. In Render, choose **New → Blueprint** and select the repository containing `render.yaml`.
3. Review the service and environment variables. Set the Google OAuth client ID/secret and all AI keys you intend to use.
4. After Render creates the service, copy its HTTPS URL, for example `https://creatorpilot-mcp.onrender.com`.
5. Update `GOOGLE_REDIRECT_URI` to `https://YOUR-SERVICE.onrender.com/api/auth/google/callback` in Render and in Google Cloud Console's authorized redirect URIs.
6. Set `WEB_ORIGIN` to the origin of the dashboard. For this first MCP-only deployment, the dashboard can remain separately hosted or be omitted; the `/mcp` tools are the ChatGPT interface.
7. Redeploy, then open `https://YOUR-SERVICE.onrender.com/connect-youtube` in Safari and complete Google authorization.
8. In Render's environment settings, copy the generated `MCP_ACCESS_TOKEN` value securely. Do not paste it into a public chat or repository.

### Connect to ChatGPT

ChatGPT's custom MCP connection is configured from ChatGPT on the web, where available:
1. Open ChatGPT web and go to **Settings → Apps / Plugins** (the exact label varies by rollout and workspace).
2. Choose **Add custom MCP server**.
3. Name it `CreatorPilot`.
4. Set server URL to `https://YOUR-SERVICE.onrender.com/mcp`.
5. Choose bearer-token authentication and enter the `MCP_ACCESS_TOKEN` value.
6. Review the permissions and create the app.
7. Test `channel_overview`, then `analyze_channel`.
8. To change a video, first create a proposal and inspect it. Call `approve_proposal` only after you explicitly approve that exact proposal.

### Availability caveat

OpenAI's current documentation describes custom MCP app connection as a web workflow, not an iPhone app installation workflow. Full write/modify MCP support is plan/workspace dependent; Business and Enterprise/Edu have documented full support, while Pro access is more limited. Verify your account's current Apps/Plugins settings before paying for hosting. If the iPhone app does not expose the connected custom app, use ChatGPT web in Safari where your account supports it, or use the hosted CreatorPilot dashboard as the iPhone interface.

### Security notes

- Treat the MCP bearer token as a password. Rotate it if exposed.
- The current OAuth token file is persisted as a local file; encrypt it or use a managed secret store before production.
- The app has no multi-user tenant isolation.
- Use HTTPS only.
- Do not enable public unauthenticated MCP access.
- Review each proposal before calling `approve_proposal`.
- YouTube API quotas and Google's OAuth verification requirements apply.
